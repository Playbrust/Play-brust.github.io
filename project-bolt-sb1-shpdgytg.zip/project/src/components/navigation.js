export function initNavigation() {
  const header = document.getElementById('header');
  
  if (!header) return;
  
  header.innerHTML = `
    <div class="container">
      <nav class="flex items-center justify-between h-20">
        <a href="#" class="flex items-center">
          <svg class="w-8 h-8 text-primary-500" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
          </svg>
          <span class="ml-2 text-xl font-bold">Horizon</span>
        </a>
        
        <div class="hidden md:flex items-center space-x-1">
          <a href="#features" class="nav-link">Features</a>
          <a href="#demo" class="nav-link">Demo</a>
          <a href="#testimonials" class="nav-link">Testimonials</a>
          <a href="#pricing" class="nav-link">Pricing</a>
        </div>
        
        <div class="hidden md:flex items-center space-x-4">
          <a href="#" class="text-neutral-600 font-medium hover:text-primary-500 transition-colors duration-250">Log in</a>
          <a href="#" class="btn btn-primary">Get Started</a>
        </div>
        
        <button id="mobile-menu-button" class="md:hidden text-neutral-500 hover:text-neutral-700 focus:outline-none">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
          </svg>
        </button>
      </nav>
      
      <div id="mobile-menu" class="hidden md:hidden py-4 px-4 bg-white border-t border-neutral-100">
        <div class="flex flex-col space-y-3">
          <a href="#features" class="nav-link">Features</a>
          <a href="#demo" class="nav-link">Demo</a>
          <a href="#testimonials" class="nav-link">Testimonials</a>
          <a href="#pricing" class="nav-link">Pricing</a>
          <div class="pt-4 border-t border-neutral-100">
            <a href="#" class="block py-2 text-neutral-600 font-medium hover:text-primary-500">Log in</a>
            <a href="#" class="block w-full btn btn-primary text-center mt-3">Get Started</a>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Mobile menu toggle
  const mobileMenuButton = document.getElementById('mobile-menu-button');
  const mobileMenu = document.getElementById('mobile-menu');
  
  if (mobileMenuButton && mobileMenu) {
    mobileMenuButton.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  }
  
  // Close mobile menu when clicking outside
  document.addEventListener('click', (event) => {
    if (mobileMenu && !mobileMenu.contains(event.target) && 
        mobileMenuButton && !mobileMenuButton.contains(event.target) &&
        !mobileMenu.classList.contains('hidden')) {
      mobileMenu.classList.add('hidden');
    }
  });
  
  // Active link highlighting based on scroll position
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section');
  
  window.addEventListener('scroll', () => {
    let current = '';
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      
      if (window.scrollY >= (sectionTop - 100)) {
        current = section.getAttribute('id');
      }
    });
    
    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });
}