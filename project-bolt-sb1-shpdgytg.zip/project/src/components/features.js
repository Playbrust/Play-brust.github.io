export function initFeatures() {
  const featuresSection = document.getElementById('features');
  
  if (!featuresSection) return;
  
  featuresSection.innerHTML = `
    <div class="container">
      <div class="text-center max-w-3xl mx-auto mb-16">
        <h2 class="text-3xl md:text-4xl font-bold mb-4" data-aos="fade-up">Why choose Horizon?</h2>
        <p class="text-lg text-neutral-600" data-aos="fade-up" data-aos-delay="100">
          Our platform provides everything you need to create stunning digital experiences that drive results.
        </p>
      </div>
      
      <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        ${renderFeatureCard({
          icon: '<path d="M13 10V3L4 14h7v7l9-11h-7z"></path>',
          title: 'Lightning Fast',
          description: 'Optimized for speed with cutting-edge performance that keeps your users engaged.'
        })}
        
        ${renderFeatureCard({
          icon: '<path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path><path d="M12 8v4"></path><path d="M12 16h.01"></path>',
          title: 'Intuitive Design',
          description: 'User-friendly interface that makes complex tasks simple and enjoyable.'
        })}
        
        ${renderFeatureCard({
          icon: '<path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z"></path><path d="M9 12l2 2 4-4"></path>',
          title: 'Reliable & Secure',
          description: 'Built with security in mind, ensuring your data is always protected.'
        })}
        
        ${renderFeatureCard({
          icon: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><path d="M3.27 6.96L12 12.01l8.73-5.05"></path><path d="M12 22.08V12"></path>',
          title: 'Powerful Analytics',
          description: 'Comprehensive insights that help you understand user behavior and optimize accordingly.'
        })}
        
        ${renderFeatureCard({
          icon: '<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path>',
          title: 'Customizable',
          description: 'Easily adapt to your brand\'s look and feel with extensive customization options.'
        })}
        
        ${renderFeatureCard({
          icon: '<path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>',
          title: 'Developer Friendly',
          description: 'Extensive documentation and APIs that make integration and development seamless.'
        })}
      </div>
    </div>
  `;
  
  // Initialize demo section right after features
  const demoSection = document.getElementById('demo');
  
  if (demoSection) {
    demoSection.innerHTML = `
      <div class="container">
        <div class="flex flex-col lg:flex-row items-center">
          <div class="w-full lg:w-1/2 mb-10 lg:mb-0">
            <h2 class="text-3xl md:text-4xl font-bold mb-6" data-aos="fade-up">See Horizon in action</h2>
            <p class="text-lg text-neutral-600 mb-8 max-w-lg" data-aos="fade-up" data-aos-delay="100">
              Watch how easily you can create beautiful, functional digital experiences with our platform.
            </p>
            <ul class="space-y-4" data-aos="fade-up" data-aos-delay="200">
              ${renderFeatureListItem('Drag-and-drop interface for easy design')}
              ${renderFeatureListItem('Responsive layouts that work on all devices')}
              ${renderFeatureListItem('Pre-built components to speed up development')}
              ${renderFeatureListItem('Real-time collaboration for teams')}
            </ul>
            <a href="#" class="btn btn-primary mt-8" data-aos="fade-up" data-aos-delay="300">
              Start Free Trial
            </a>
          </div>
          <div class="w-full lg:w-1/2 flex justify-center" data-aos="fade-left" data-aos-delay="400">
            <div class="relative rounded-xl overflow-hidden shadow-2xl border border-neutral-200">
              <div class="absolute inset-0 bg-gradient-to-r from-primary-500 to-secondary-500 opacity-50"></div>
              <div class="relative">
                <div class="flex items-center bg-neutral-900 px-4 py-2 border-b border-neutral-700">
                  <div class="flex space-x-2">
                    <div class="w-3 h-3 rounded-full bg-error-500"></div>
                    <div class="w-3 h-3 rounded-full bg-warning-500"></div>
                    <div class="w-3 h-3 rounded-full bg-success-500"></div>
                  </div>
                  <div class="text-center flex-1">
                    <span class="text-neutral-400 text-sm">horizon-demo.app</span>
                  </div>
                </div>
                <img 
                  src="https://images.pexels.com/photos/93398/pexels-photo-93398.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Product demo" 
                  class="w-full max-w-lg"
                />
                <div class="absolute inset-0 flex items-center justify-center bg-neutral-900 bg-opacity-40">
                  <button class="w-16 h-16 rounded-full bg-white bg-opacity-90 flex items-center justify-center shadow-lg hover:bg-opacity-100 transition-all duration-250">
                    <svg class="w-6 h-6 text-primary-500" fill="currentColor" viewBox="0 0 20 20">
                      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
}

function renderFeatureCard({ icon, title, description, delay = 0 }) {
  return `
    <div class="card card-hover" data-aos="fade-up" data-aos-delay="${delay}">
      <div class="feature-icon bg-gradient-primary">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
          ${icon}
        </svg>
      </div>
      <h3 class="text-xl font-semibold mb-2">${title}</h3>
      <p class="text-neutral-600">${description}</p>
    </div>
  `;
}

function renderFeatureListItem(text) {
  return `
    <li class="flex items-start">
      <svg class="w-5 h-5 text-success-500 mt-1 mr-2" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
      </svg>
      <span>${text}</span>
    </li>
  `;
}