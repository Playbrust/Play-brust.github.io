import Swiper from 'swiper';
import 'swiper/css';

export function initTestimonials() {
  const testimonialSection = document.getElementById('testimonials');
  
  if (!testimonialSection) return;
  
  testimonialSection.innerHTML = `
    <div class="container">
      <div class="text-center max-w-3xl mx-auto mb-16">
        <h2 class="text-3xl md:text-4xl font-bold mb-4" data-aos="fade-up">What our customers say</h2>
        <p class="text-lg text-neutral-600" data-aos="fade-up" data-aos-delay="100">
          Don't just take our word for it — hear from some of our amazing customers
        </p>
      </div>
      
      <div class="swiper-container testimonial-slider" data-aos="fade-up" data-aos-delay="200">
        <div class="swiper-wrapper">
          ${renderTestimonial({
            content: "Horizon has completely transformed how we build and deploy our digital products. The ease of use and powerful features have saved us countless hours.",
            author: "Sarah Johnson",
            role: "CTO at TechForms",
            image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          })}
          
          ${renderTestimonial({
            content: "I've tried numerous platforms, but Horizon stands out for its intuitive design and exceptional performance. Our team's productivity has increased dramatically.",
            author: "Michael Chen",
            role: "Product Director at InnovateCo",
            image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          })}
          
          ${renderTestimonial({
            content: "The analytics capabilities alone make Horizon worth it. We now have insights that help us make data-driven decisions to improve our user experience.",
            author: "Emma Davis",
            role: "UX Designer at CreativeEdge",
            image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          })}
          
          ${renderTestimonial({
            content: "Customer support is exceptional. Any time we've had questions, the team has been responsive and helpful. It's clear they care about their customers.",
            author: "David Wilson",
            role: "CEO at StartupVision",
            image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          })}
        </div>
        
        <div class="mt-10 flex justify-center items-center space-x-2">
          <button class="testimonial-prev w-10 h-10 flex items-center justify-center rounded-full border border-neutral-300 text-neutral-600 hover:bg-neutral-50">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
            </svg>
          </button>
          <button class="testimonial-next w-10 h-10 flex items-center justify-center rounded-full border border-neutral-300 text-neutral-600 hover:bg-neutral-50">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
            </svg>
          </button>
        </div>
      </div>
      
      <div class="mt-20 py-10 px-8 md:px-16 bg-white rounded-2xl shadow-apple border border-neutral-100" data-aos="fade-up">
        <div class="flex flex-col md:flex-row items-center">
          <div class="mb-6 md:mb-0 md:mr-10">
            <div class="flex items-center space-x-2">
              ${renderStar()}${renderStar()}${renderStar()}${renderStar()}${renderStar()}
            </div>
            <p class="mt-2 text-sm text-neutral-600">Based on 500+ reviews</p>
          </div>
          
          <div class="flex flex-wrap gap-4 justify-center md:justify-start">
            <div class="flex items-center bg-neutral-50 rounded-lg px-4 py-2 border border-neutral-100">
              <img src="https://seeklogo.com/images/G/google-2015-logo-65BBD07B01-seeklogo.com.png" alt="Google" class="h-5" />
              <div class="ml-2 flex items-center">
                ${renderStar(4)}${renderStar(4)}${renderStar(4)}${renderStar(4)}${renderStar(4)}
                <span class="ml-1 text-sm font-medium">4.9</span>
              </div>
            </div>
            
            <div class="flex items-center bg-neutral-50 rounded-lg px-4 py-2 border border-neutral-100">
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Logo_of_Trustpilot.svg/2560px-Logo_of_Trustpilot.svg.png" alt="Trustpilot" class="h-5" />
              <div class="ml-2 flex items-center">
                ${renderStar(4)}${renderStar(4)}${renderStar(4)}${renderStar(4)}${renderHalfStar()}
                <span class="ml-1 text-sm font-medium">4.8</span>
              </div>
            </div>
            
            <div class="flex items-center bg-neutral-50 rounded-lg px-4 py-2 border border-neutral-100">
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Capterra_logo.svg/2560px-Capterra_logo.svg.png" alt="Capterra" class="h-5" />
              <div class="ml-2 flex items-center">
                ${renderStar(4)}${renderStar(4)}${renderStar(4)}${renderStar(4)}${renderStar(4)}
                <span class="ml-1 text-sm font-medium">4.9</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Initialize Swiper
  setTimeout(() => {
    const testimonialSlider = new Swiper('.testimonial-slider', {
      slidesPerView: 1,
      spaceBetween: 32,
      loop: true,
      autoplay: {
        delay: 5000,
      },
      breakpoints: {
        640: {
          slidesPerView: 1,
        },
        768: {
          slidesPerView: 2,
        },
        1024: {
          slidesPerView: 3,
        },
      },
      navigation: {
        nextEl: '.testimonial-next',
        prevEl: '.testimonial-prev',
      },
    });
  }, 0);
}

function renderTestimonial({ content, author, role, image }) {
  return `
    <div class="swiper-slide">
      <div class="bg-white rounded-xl p-6 shadow-apple h-full flex flex-col">
        <div class="flex items-center space-x-1 mb-4">
          ${renderStar()}${renderStar()}${renderStar()}${renderStar()}${renderStar()}
        </div>
        <p class="flex-grow text-neutral-700 mb-6">"${content}"</p>
        <div class="flex items-center">
          <img src="${image}" alt="${author}" class="w-12 h-12 rounded-full object-cover" />
          <div class="ml-3">
            <h4 class="font-semibold">${author}</h4>
            <p class="text-sm text-neutral-600">${role}</p>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderStar(size = 5) {
  return `
    <svg class="w-${size} h-${size} text-warning-500" fill="currentColor" viewBox="0 0 20 20">
      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
    </svg>
  `;
}

function renderHalfStar(size = 5) {
  return `
    <svg class="w-${size} h-${size} text-warning-500" viewBox="0 0 20 20">
      <defs>
        <linearGradient id="halfStar" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="50%" stop-color="currentColor"></stop>
          <stop offset="50%" stop-color="#D1D5DB"></stop>
        </linearGradient>
      </defs>
      <path fill="url(#halfStar)" d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
    </svg>
  `;
}