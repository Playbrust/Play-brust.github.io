export function initHero() {
  const heroSection = document.getElementById('hero');
  
  if (!heroSection) return;
  
  heroSection.innerHTML = `
    <div class="container">
      <div class="flex flex-col-reverse lg:flex-row items-center">
        <div class="w-full lg:w-1/2 pt-10 lg:pt-0">
          <h1 class="slide-up-delay-1 text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
            Building the future of digital experiences
          </h1>
          <p class="slide-up-delay-2 text-xl text-neutral-600 mb-8 max-w-lg">
            Create beautiful, responsive websites and applications with our powerful and intuitive platform.
          </p>
          <div class="slide-up-delay-3 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <a href="#" class="btn btn-primary">Get Started</a>
            <a href="#demo" class="btn btn-outline">
              <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd"></path>
              </svg>
              Watch Demo
            </a>
          </div>
          <div class="slide-up-delay-3 mt-10 hidden md:flex items-center space-x-8">
            <div class="flex -space-x-2">
              <img class="inline-block h-8 w-8 rounded-full ring-2 ring-white" src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="">
              <img class="inline-block h-8 w-8 rounded-full ring-2 ring-white" src="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="">
              <img class="inline-block h-8 w-8 rounded-full ring-2 ring-white" src="https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="">
              <div class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary-100 ring-2 ring-white">
                <span class="text-xs font-medium text-primary-600">+5K</span>
              </div>
            </div>
            <p class="text-sm text-neutral-600">
              <span class="font-semibold">5,000+</span> professionals trust Horizon
            </p>
          </div>
        </div>
        <div class="w-full lg:w-1/2 flex justify-center lg:justify-end mb-10 lg:mb-0">
          <div class="relative">
            <div class="absolute -top-10 -left-10 w-40 h-40 bg-primary-100 rounded-full opacity-70 filter blur-2xl animate-pulse-slow"></div>
            <div class="absolute -bottom-10 -right-10 w-40 h-40 bg-accent-100 rounded-full opacity-70 filter blur-2xl animate-pulse-slow"></div>
            <img 
              src="https://images.pexels.com/photos/8439094/pexels-photo-8439094.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Dashboard preview" 
              class="w-full max-w-md rounded-xl shadow-2xl relative z-10 border border-neutral-200"
            />
          </div>
        </div>
      </div>
    </div>
  `;
}