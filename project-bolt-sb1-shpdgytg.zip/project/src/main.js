import './styles/main.css';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { initNavigation } from './components/navigation';
import { initHero } from './components/hero';
import { initFeatures } from './components/features';
import { initTestimonials } from './components/testimonials';
import { initPricing } from './components/pricing';
import { initNewsletter } from './components/newsletter';
import { initFooter } from './components/footer';

// Initialize AOS (Animate On Scroll)
AOS.init({
  duration: 800,
  easing: 'ease-out',
  once: true,
  offset: 100,
});

// Initialize all components
document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  
  // Build the page structure
  app.innerHTML = `
    <header id="header" class="fixed top-0 left-0 w-full z-50"></header>
    <main>
      <section id="hero" class="min-h-screen flex items-center"></section>
      <section id="features" class="py-20 bg-neutral-50"></section>
      <section id="demo" class="py-20"></section>
      <section id="testimonials" class="py-20 bg-neutral-50"></section>
      <section id="pricing" class="py-20"></section>
      <section id="newsletter" class="py-20 bg-primary-500"></section>
    </main>
    <footer id="footer" class="bg-neutral-900 text-white py-16"></footer>
  `;
  
  // Initialize each component
  initNavigation();
  initHero();
  initFeatures();
  initTestimonials();
  initPricing();
  initNewsletter();
  initFooter();
  
  // Add scroll behavior for navigation links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        window.scrollTo({
          top: target.offsetTop - 80, // Adjust for header height
          behavior: 'smooth'
        });
      }
    });
  });
});

// Handle scroll events
window.addEventListener('scroll', () => {
  const header = document.getElementById('header');
  if (window.scrollY > 50) {
    header.classList.add('bg-white', 'shadow');
    header.classList.remove('bg-transparent');
  } else {
    header.classList.remove('bg-white', 'shadow');
    header.classList.add('bg-transparent');
  }
});